#!/usr/bin/env python3
"""Exercise a specified PR #13 Swift sidecar build on loopback under the outer GPU lock."""
import argparse
import json
import math
from pathlib import Path
import socket
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("label")
parser.add_argument("bundle")
parser.add_argument("--binary", required=True)
args = parser.parse_args()
binary = Path(args.binary).resolve()
server_log = ROOT / "logs" / (args.label + "-server.log")
with socket.socket() as sock:
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
command = [str(binary), "--model", str(Path(args.bundle).resolve()), "--port", str(port), "--seed", "212"]
print(json.dumps({"event": "sidecar_start", "command": command}), flush=True)

def request(path, payload=None):
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=data,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as response:
        result = json.load(response)
        assert response.status == 200
    return result

with server_log.open("xb") as log:
    process = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    try:
        deadline = time.monotonic() + 240
        while True:
            if process.poll() is not None:
                raise RuntimeError(f"sidecar exited {process.returncode}; see {server_log}")
            try:
                health = request("/health")
                assert health["ok"] is True
                break
            except (OSError, ValueError):
                if time.monotonic() > deadline:
                    raise TimeoutError("sidecar health timeout")
                time.sleep(0.5)
        print(json.dumps({"event": "health_pass", "response": health}), flush=True)
        cases = [
            ("/prefill_throughput", {"prompt_tokens": 32}, {"prompt_tokens": 32}, "prompt_tps"),
            ("/decode_throughput", {"prompt_tokens": 32, "decode_tokens": 16}, {"decode_tokens": 16}, "generation_tps"),
            ("/end_to_end_latency", {"prompt_tokens": 32, "decode_tokens": 16},
             {"prompt_tokens": 32, "completion_tokens": 16}, "total_ms"),
            ("/max_memory_usage", {"prompt_tokens": 8, "decode_tokens": 1},
             {"prompt_tokens": 8, "completion_tokens": 1}, None),
            ("/decode_throughput", {"prompt_tokens": 32, "decode_tokens": 16}, {"decode_tokens": 16}, "generation_tps"),
        ]
        for endpoint, payload, expected, rate in cases:
            result = request(endpoint, payload)
            print(json.dumps({"event": "http_result", "endpoint": endpoint, "request": payload,
                              "response": result}), flush=True)
            assert all(result.get(k) == v for k, v in expected.items()), (endpoint, result)
            if rate:
                assert math.isfinite(result[rate]) and result[rate] > 0
        print(json.dumps({"event": "sidecar_smoke_pass", "label": args.label,
                          "scope": "Swift HTTP contract only; no Rust CLI or runtime-identity claim"}), flush=True)
    finally:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        print(json.dumps({"event": "sidecar_stopped", "returncode": process.returncode}), flush=True)
