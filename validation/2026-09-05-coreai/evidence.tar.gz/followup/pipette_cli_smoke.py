#!/usr/bin/env python3
"""Run the official-pinned consumer through its own Rust cache and CLI."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("--resume", action="store_true")
args = parser.parse_args()
ROOT = Path(__file__).resolve().parents[1]
BINARY = ROOT / "work/pipette/target/debug/pipette"
WORK = ROOT / "work/pipette-cli-workspace"
WORK.mkdir(exist_ok=True)
PREFIX = ["env", "PIPETTE_READINESS_MAX_WAIT_SECS=90", "PIPETTE_WORK_DIR=" + str(WORK),
          "PIPETTE_COREAI_CACHE=" + str(ROOT / "work/pipette-cli-cache"),
          "PIPETTE_COREAI_SWIFT=" + str(ROOT / "work/pipette/crates/pipette-coreai/swift"),
          str(BINARY)]
RUNTIME = "core-ai-macos-pipette://version=27a66f90e7f3fd9b83a6acb7bcb0a4a5ff71fd60"

def run(label, args, gpu=False):
    command = ["python3", str(ROOT / "harness/run_logged.py"), "--timeout", "600"]
    if gpu:
        command.append("--gpu")
    command += [label, "--"] + PREFIX + args
    subprocess.run(command, cwd=ROOT, check=True, stdout=subprocess.DEVNULL)
    print(label + " passed", flush=True)

if not args.resume:
    run("followup-cli-init", ["init"])
    run("followup-cli-runtime-pull", ["runtimes", "pull", "--runtime", RUNTIME])
    run("followup-cli-benchmarks-init", ["benchmarks", "init-local"])
for fixture in ["s1", "pipette27b"]:
    model = {"type": "core_ai", "source": "absolute_dir", "dir": str(ROOT / "work/bundles" / fixture)}
    run("followup-cli-v2-decode-" + fixture,
        ["benchmarks", "run", "--benchmark", "local/decode_throughput_smoke",
         "--model", json.dumps(model), "--runtime", RUNTIME], gpu=True)
run("followup-cli-results", ["results", "list"])
files = list((ROOT / "work/pipette-cli-cache").glob("*/pipette-coreai-sidecar"))
assert len(files) == 1
cached = files[0]
built = ROOT / "work/pipette/crates/pipette-coreai/swift/.build/release/pipette-coreai-sidecar"
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(cached) == digest(built)
result = {"cli_sha256": digest(BINARY), "cache_key": cached.parent.name,
          "cached_sidecar_sha256": digest(cached), "built_sidecar_sha256": digest(built),
          "prebuilt_binary_override": False, "runtime_uri": RUNTIME,
          "note": "Local CLI smoke results only; no management-server sync or benchmark ranking claim."}
(ROOT / "followup/pipette-cli-result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result), flush=True)
