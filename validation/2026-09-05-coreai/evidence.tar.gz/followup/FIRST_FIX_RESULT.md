# First follow-up result — 2026-09-05

Current official source: `27a66f90e7f3fd9b83a6acb7bcb0a4a5ff71fd60` (PR #227 merged).

The 27B continuation discrepancy reproduces on current main. A four-line
change truncating token history to `processedTokenCount` before prefix
resolution makes the same continuation token-identical to full replay.
The continued/replayed processed counts both become 91 (previously 90/91).
The Qwen3.5 0.8B S=1 and dynamic Qwen3 0.6B gates also pass with count checks.
Hybrid partial rewind remains explicitly rejected; full reset/replay passes.

These results are saved before publication and further consumer tests.
See `results.json` and `../logs/followup-{current,fix}-*.log`.
