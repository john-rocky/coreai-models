#!/usr/bin/env python3
"""Fetch only pinned macOS bundle files, verify Git/LFS hashes, save a manifest."""
import hashlib
import json
from pathlib import Path
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
SPECS = [
    ("s1", "mlboydaisuke/qwen3.5-0.8B-CoreAI", "df983f659f8501f3da0892baca4c39523594716b",
     "gpu-pipelined-b2/qwen3_5_0_8b_decode_int8hu_block32_sym"),
    ("dynamic", "mlboydaisuke/qwen3-0.6b-CoreAI-official", "7ecc49f36eb49415a0d1888d6de5e1f5bc79a113", "macos"),
]

def main():
    manifest = []
    for label, repo, revision, prefix in SPECS:
        api = f"https://huggingface.co/api/models/{repo}/revision/{revision}?blobs=true"
        with urllib.request.urlopen(api, timeout=60) as response:
            info = json.load(response)
        assert info["sha"] == revision
        (ROOT / "upstream" / f"hf-pinned-{label}.json").write_text(json.dumps(info, indent=2) + "\n")
        bundle_dir = ROOT / "work" / "bundles" / label
        entry = dict(label=label, repo=repo, revision=revision, prefix=prefix, local_path=str(bundle_dir), files=[])
        for file in info["siblings"]:
            name = file["rfilename"]
            if not name.startswith(prefix + "/"):
                continue
            rel = name[len(prefix) + 1:]
            target = bundle_dir / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            url = f"https://huggingface.co/{repo}/resolve/{revision}/{name}"
            if not target.exists() or target.stat().st_size != file["size"]:
                temp = target.with_name(target.name + ".part")
                for attempt in range(3):
                    try:
                        print(f"FETCH {label} {rel} {file['size']} bytes", flush=True)
                        with urllib.request.urlopen(url, timeout=60) as response, temp.open("wb") as out:
                            while chunk := response.read(8 * 1024 * 1024):
                                out.write(chunk)
                        assert temp.stat().st_size == file["size"], (rel, temp.stat().st_size)
                        temp.replace(target)
                        break
                    except Exception:
                        if attempt == 2:
                            raise
                        time.sleep(2)
            sha = hashlib.sha256()
            git = hashlib.sha1(f"blob {target.stat().st_size}\0".encode())
            with target.open("rb") as stream:
                while chunk := stream.read(8 * 1024 * 1024):
                    sha.update(chunk)
                    git.update(chunk)
            if file.get("lfs"):
                assert sha.hexdigest() == file["lfs"]["sha256"], rel
            else:
                assert git.hexdigest() == file["blobId"], rel
            entry["files"].append(dict(path=rel, size=target.stat().st_size, sha256=sha.hexdigest(),
                                       git_blob=file["blobId"], source_url=url))
            print(f"VERIFIED {label} {rel} {sha.hexdigest()}", flush=True)
        assert any(f["path"] == "metadata.json" for f in entry["files"])
        manifest.append(entry)
        (ROOT / "bundles.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print("BUNDLES_READY", flush=True)

if __name__ == "__main__":
    main()
