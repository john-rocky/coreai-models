#!/usr/bin/env python3
"""Create consumer packages outside both unmodified Apple source worktrees."""
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
for label in ["before", "after"]:
    project = ROOT / "work" / f"gate-{label}"
    project.mkdir(exist_ok=True)
    (project / "Sources").mkdir(exist_ok=True)
    shutil.copy2(ROOT / "harness" / "main.swift", project / "Sources" / "main.swift")
    source = str(ROOT / "work" / label)
    sidecar = ""
    if label == "after":
        (project / "PipetteSources").mkdir(exist_ok=True)
        shutil.copy2(ROOT / "upstream/pipette-main.swift", project / "PipetteSources/main.swift")
        sidecar = ''',
        .executableTarget(name: "pipette-coreai-sidecar",
            dependencies: [.product(name: "CoreAILM", package: "coreai-models")], path: "PipetteSources")'''
    (project / "Package.swift").write_text('''// swift-tools-version: 6.0
import PackageDescription
let package = Package(
    name: "bundle-gate",
    platforms: [.macOS("27.0")],
    dependencies: [.package(name: "coreai-models", path: SOURCE_PATH)],
    targets: [.executableTarget(name: "bundle-gate",
        dependencies: [.product(name: "CoreAILM", package: "coreai-models")], path: "Sources")SIDECAR]
)
'''.replace("SOURCE_PATH", json.dumps(source)).replace("SIDECAR", sidecar))
    shutil.copy2(ROOT / "work" / label / "Package.resolved", project / "Package.resolved")
    print(project)
