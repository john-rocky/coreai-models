#!/usr/bin/env python3
"""Persist command, environment overrides, exit status and output for each attempt."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("label")
parser.add_argument("--timeout", type=int, default=900)
parser.add_argument("--gpu", action="store_true")
parser.add_argument("--cwd", default=str(ROOT))
parser.add_argument("command", nargs=argparse.REMAINDER)
args = parser.parse_args()
cmd = args.command
if cmd and cmd[0] == "--":
    cmd = cmd[1:]
if not cmd:
    parser.error("command required")
env = os.environ.copy()
env.pop("COREAI_CHUNK_THRESHOLD", None)
env["DEVELOPER_DIR"] = env.get("VALIDATION_DEVELOPER_DIR", "/Applications/Xcode-27.0.0-Beta.5.app")
lock_script = Path(env.get("COREAI_GPU_LOCK_RUNNER", "/Users/majimadaisuke/code/coreai-kit/scripts/with-gpu-lock.py"))
executable = Path(cmd[0])
if not executable.is_absolute():
    executable = Path(args.cwd) / executable
binary_sha = hashlib.sha256(executable.read_bytes()).hexdigest() if executable.is_file() else None
if args.gpu:
    cmd = ["python3", str(lock_script), "--"] + cmd
record = dict(label=args.label, command=cmd, shell_command=shlex.join(cmd), cwd=args.cwd,
              env_overrides={"DEVELOPER_DIR": env["DEVELOPER_DIR"], "COREAI_CHUNK_THRESHOLD": None},
              gpu_lock=str(lock_script) if args.gpu else None,
              executable_sha256=binary_sha,
              started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), status="running")
meta = ROOT / "logs" / (args.label + ".result.json")
log = ROOT / "logs" / (args.label + ".log")
if meta.exists() or log.exists():
    raise SystemExit("Refusing to overwrite an earlier attempt; choose a new label")
meta.write_text(json.dumps(record, indent=2) + "\n")
started = time.monotonic()
with log.open("wb") as output:
    process = subprocess.Popen(cmd, cwd=args.cwd, env=env, stdout=output, stderr=subprocess.STDOUT,
                               start_new_session=True)
    record["pid"] = process.pid
    record["harness_sha256"] = hashlib.sha256((ROOT / "harness/main.swift").read_bytes()).hexdigest()
    meta.write_text(json.dumps(record, indent=2) + "\n")
    try:
        code = process.wait(timeout=args.timeout)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        code = 124
        record["timed_out"] = True
record.update(status="completed", exit_code=code, duration_seconds=time.monotonic() - started,
              ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), log=str(log))
meta.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2), flush=True)
raise SystemExit(code if code >= 0 else 128 - code)
