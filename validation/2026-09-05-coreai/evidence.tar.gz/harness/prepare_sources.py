#!/usr/bin/env python3
"""Prepare detached public source worktrees without changing a shared checkout."""
import json
from pathlib import Path
import subprocess
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
WORK.mkdir(exist_ok=True)
BEFORE = "0ec2531cb080bf1312dc98a8e755befbf033bf91"
AFTER = "d237ee3e75edfa6e053bbdbef8414b5dc2b1ef03"
PIPETTE = "03ae30302ea2f648259c1e6f10370c47fc0a0b7f"

def run(*cmd):
    print(json.dumps(list(cmd)), flush=True)
    subprocess.run(cmd, check=True)

repo = WORK / "apple"
if not repo.exists():
    run("git", "clone", "--no-checkout", "https://github.com/apple/coreai-models.git", str(repo))
for label, sha in [("before", BEFORE), ("after", AFTER)]:
    exists = subprocess.run(["git", "-C", str(repo), "cat-file", "-e", sha + "^{commit}"],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    if not exists:
        run("git", "-C", str(repo), "fetch", "https://github.com/apple/coreai-models.git", sha)
    target = WORK / label
    if not target.exists():
        run("git", "-C", str(repo), "worktree", "add", "--detach", str(target), sha)
    actual = subprocess.check_output(["git", "-C", str(target), "rev-parse", "HEAD"], text=True).strip()
    dirty = subprocess.check_output(["git", "-C", str(target), "status", "--porcelain"], text=True)
    assert actual == sha and not dirty, (target, actual, dirty)

path = "crates/pipette-coreai/swift/Sources/pipette-coreai-sidecar/main.swift"
with urllib.request.urlopen(f"https://raw.githubusercontent.com/Liquid4All/pipette-clients/{PIPETTE}/{path}", timeout=30) as response:
    data = response.read()
saved = ROOT / "upstream/pipette-main.swift"
if saved.exists():
    assert saved.read_bytes() == data
else:
    saved.parent.mkdir(exist_ok=True)
    saved.write_bytes(data)
print("PINNED_SOURCES_READY", flush=True)
