#!/usr/bin/env python3
"""Resume the pinned S=1 graph with checked HTTP ranges; verify its LFS SHA-256."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
info = json.loads((ROOT / "upstream/hf-pinned-s1.json").read_text())
name = "gpu-pipelined-b2/qwen3_5_0_8b_decode_int8hu_block32_sym/qwen3_5_0_8b_decode_int8hu_block32_sym.aimodel/main.mlirb"
entry = next(f for f in info["siblings"] if f["rfilename"] == name)
url = f"https://huggingface.co/{info['id']}/resolve/{info['sha']}/{name}"
target = ROOT / "work/bundles/s1/qwen3_5_0_8b_decode_int8hu_block32_sym.aimodel/main.mlirb"
partial = target.with_name(target.name + ".part")
staged = target.with_name(target.name + ".ranges")
prefix = partial.stat().st_size if partial.exists() else 0
if prefix:
    shutil.copyfile(partial, staged)
fd = os.open(staged, os.O_CREAT | os.O_RDWR, 0o644)
os.ftruncate(fd, entry["size"])

def fetch(start, end):
    for attempt in range(3):
        try:
            request = urllib.request.Request(url, headers={"Range": f"bytes={start}-{end}"})
            with urllib.request.urlopen(request, timeout=60) as response:
                assert response.status == 206
                assert response.headers["Content-Range"] == f"bytes {start}-{end}/{entry['size']}"
                offset = start
                while block := response.read(1024 * 1024):
                    written = os.pwrite(fd, block, offset)
                    assert written == len(block)
                    offset += written
                assert offset == end + 1
            return end - start + 1
        except Exception:
            if attempt == 2:
                raise
            time.sleep(1)

try:
    done = prefix
    print(f"RESUME {prefix}/{entry['size']} bytes, 16 HTTP workers", flush=True)
    with ThreadPoolExecutor(max_workers=16) as pool:
        futures = [pool.submit(fetch, start, min(start + 16 * 1024 * 1024 - 1, entry["size"] - 1))
                   for start in range(prefix, entry["size"], 16 * 1024 * 1024)]
        for future in as_completed(futures):
            done += future.result()
            print(f"FETCHED {done}/{entry['size']}", flush=True)
finally:
    os.close(fd)
sha = hashlib.sha256()
with staged.open("rb") as stream:
    while block := stream.read(8 * 1024 * 1024):
        sha.update(block)
assert sha.hexdigest() == entry["lfs"]["sha256"]
staged.replace(target)
print(f"VERIFIED {sha.hexdigest()}", flush=True)
