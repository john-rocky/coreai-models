# First runtime result — saved immediately

Observed 2026-09-05 JST (run 2026-09-04T21:44:59Z–21:45:56Z).

- Source: Apple PR #227 `d237ee3e75edfa6e053bbdbef8414b5dc2b1ef03`.
- Bundle: `mlboydaisuke/Qwen3.8-27B-CoreAI` revision `2f66df29215a6fa7ce59d320225dcaa8cc4f15c2`, `gpu-pipelined/qwen3_8_27b_decode_int4lin`; all local files match public Git/LFS hashes.
- Environment: M4 Max (Mac16,9), 128 GiB, macOS 27.0 `26A5416b`, Xcode 27 beta 5 `27A5237l`; shared GPU lock held. Chunk override unset.
- Actual descriptor: input_ids `[1,1]`, position_ids `[1,-1]`, logits `[1,1,248320]`, four states, one main function; dynamic structure selects pipelined engine.
- Constructor: PASS. Multi-token prefill and 24-token greedy generation: completed. Turn 1 includes “The capital of France is Paris.”
- Same-engine continuation: completed 24 tokens, shared-prefix match 48; starts “The Eiffel Tower”. Full reset/replay of exactly the same 68 input IDs also completed, but starts “One famous landmark in Paris is the Eiffel Tower.” Token equality gate FAIL.
- This is one observation, not an attribution to PR #227. Remaining state checks were not reached because this initial gate stops at first failure. Next: repeat in isolation, run dynamic control, preserve all independent phase results.

Commands, full token IDs, decoded output, exit code 2: `logs/after-pipette27b.log` and `logs/after-pipette27b.result.json`. The low-level fixed-token gate does not stop at EOS; trailing special tokens are retained in the log and are not presented as chat UI output.
